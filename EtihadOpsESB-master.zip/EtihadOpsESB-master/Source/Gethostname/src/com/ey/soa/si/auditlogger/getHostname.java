package com.ey.soa.si.auditlogger;

import java.net.InetAddress;

public class getHostname {

public static String getname()  {
	
	
try{
	
	InetAddress addr = InetAddress.getLocalHost();
    return addr.getHostName(); 	
	
} catch(Exception e){
	System.out.println("Error while getting host name ");
	String hostname = "Error while getting host name ";
	return hostname;
}

}
} 